module.exports = {
  title: "📊 Skill Health Snapshot",
  skills: [
    { level: "Strong", topics: ["Programming Basics"] },
    { level: "Average", topics: ["Web Architecture"] },
    { level: "Weak", topics: ["Dependency Injection", "LINQ"] }
  ]
};
