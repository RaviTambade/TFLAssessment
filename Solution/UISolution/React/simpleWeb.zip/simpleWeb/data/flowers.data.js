module.exports = [
  { id: 1, name: "Gerbera", color: "Red" },
  { id: 2, name: "Jasmine", color: "White" },
  { id: 3, name: "Orchid", color: "White" },
  { id: 4, name: "Tulip", color: "Yellow" }
];
