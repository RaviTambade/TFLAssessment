
import './App.css';
import React from 'react';

import Product from './components/product';




var  App=() => {


  return (
    <div className="App">
        <Product /> 
    </div>
  );
}

export default App;
